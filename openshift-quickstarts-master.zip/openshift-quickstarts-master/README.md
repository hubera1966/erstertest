# openshift-quickstarts
Quickstarts used by templates in https://github.com/jboss-openshift/application-templates
