#!/bin/sh

INSTALL_DIR="$1"

cp -p "${INSTALL_DIR}"/byteman.jar "${JBOSS_HOME}"
